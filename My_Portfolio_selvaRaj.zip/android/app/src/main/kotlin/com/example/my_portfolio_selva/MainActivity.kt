package com.example.my_portfolio_selva

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
