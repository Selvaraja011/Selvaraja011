import 'package:flutter/material.dart';
import 'package:my_portfolio_selva/constants/colors.dart';
import 'package:my_portfolio_selva/constants/sns_links.dart';
import 'package:my_portfolio_selva/widgets/contact_section.dart';
import 'package:my_portfolio_selva/widgets/drawer_mobile.dart';
import 'package:my_portfolio_selva/widgets/header_desktop.dart';
import 'package:my_portfolio_selva/widgets/header_mobile.dart';
import 'package:my_portfolio_selva/widgets/main_desktop.dart';
import 'package:my_portfolio_selva/widgets/main_mobile.dart';
import 'package:my_portfolio_selva/widgets/projects_section.dart';
import 'package:my_portfolio_selva/widgets/skills_Mobile.dart';
import 'package:my_portfolio_selva/widgets/skills_desktop.dart';
import 'dart:js' as js;
import "../constants/nav_items.dart";
import '../constants/size.dart';
import '../constants/skill_items.dart';
import '../widgets/custom_text_field.dart';
import '../widgets/footer.dart';
import '../widgets/project_card.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final scrollController = ScrollController();
  final List<GlobalKey> navbarKeys = List.generate(4, (index) => GlobalKey());

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final screenWidth = screenSize.width;

    return LayoutBuilder(builder: (context, constraints) {
      return Scaffold(
        key: scaffoldKey,
        backgroundColor: CustomColor.scaffoldBg,
        endDrawer: constraints.maxWidth >= kMinDesktopWidth
            ? null
            : DrawerMobile(
                onNavItemTap: (int navIndex) {
                  scaffoldKey.currentState?.closeEndDrawer();
                  scrollToSection(navIndex);
                },
              ),
        body: SingleChildScrollView(
          controller: scrollController,
          scrollDirection: Axis.vertical,
          child: Column(
            children: [
              SizedBox(key: navbarKeys.first),
              //main
              //const HeaderDesktop(),
              if (constraints.maxWidth >= kMinDesktopWidth)
                HeaderDesktop(
                  onNavMenuTap: (int navIndex) {
                    scrollToSection(navIndex);
                  },
                )
              else
                HeaderMobile(
                  onLogoTap: () {},
                  onMenuTap: () {
                    scaffoldKey.currentState?.openEndDrawer();
                  },
                ),
              //MainDesktop(),
              //MainMobile(),
              if (constraints.maxWidth >= kMinDesktopWidth)
                const MainDesktop()
              else
                const MainMobile(),
              //skills
              Container(
                key: navbarKeys[1],
                width: screenWidth,
                padding: const EdgeInsets.fromLTRB(25, 20, 25, 60),
                color: CustomColor.bgLight1,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text(
                    "What I can do",
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: CustomColor.whitePrimary),
                  ),
                  const SizedBox(height: 50),
                  //platforms and skills
                  if (constraints.maxWidth >= kMedDesktopWidth)
                    const SkillsDesktop()
                  else
                    const SkillsMobile(),
                ]),
              ),
              const SizedBox(height: 30),
              //projects
              ProjectsSection(
                key: navbarKeys[2],
              ),
              const SizedBox(height: 30),
              //contact
              ContactSection(
                key: navbarKeys[3],
              ),
              const SizedBox(height: 30),
              //Footer
              const Footer(),
            ],
          ),
        ),
      );
    });
  }

  void scrollToSection(int navIndex) {
    if (navIndex == 4) {
      //open a blog page
      js.context.callMethod(SnsLinks.blog);
      return;
    }
    final key = navbarKeys[navIndex];
    Scrollable.ensureVisible(key.currentContext!,
        duration: const Duration(milliseconds: 500), curve: Curves.easeInOut);
  }
}
