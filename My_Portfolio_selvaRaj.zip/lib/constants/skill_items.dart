const List<Map> platformItems = [
  {"img": "assets/android.png", "title": "Android Dev"},
  {"img": "assets/web.png", "title": "Web Dev"},
  {"img": "assets/ios.png", "title": "IOS Dev"},
  {"img": "assets/desktop.png", "title": "Desktop Dev"}
];
const List<Map> skillItems = [
  {"img": "assets/flutter.png", "title": "Flutter"},
  {"img": "assets/dart.png", "title": "Dart"},
  {"img": "assets/python.png", "title": "Python"},
  {"img": "assets/java.png", "title": "Java"},
  {"img": "assets/kotlin.png", "title": "Kotlin"},
  {"img": "assets/c.png", "title": "C"},
  {"img": "assets/c_plus.png", "title": "C++"},
  {"img": "assets/javascript.png", "title": "JavaScript"},
  {"img": "assets/html.png", "title": "HTML"},
  {"img": "assets/css.png", "title": "CSS"},
  {"img": "assets/react_native.png", "title": "React Native"}
];
