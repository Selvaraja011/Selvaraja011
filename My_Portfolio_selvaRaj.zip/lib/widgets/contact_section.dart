import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:my_portfolio_selva/constants/size.dart';

import '../constants/colors.dart';
import '../constants/sns_links.dart';
import 'custom_text_field.dart';
import 'dart:js' as js;

class ContactSection extends StatelessWidget {
  const ContactSection({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(25, 20, 25, 60),
      color: CustomColor.bgLight1,
      child: Column(
        //title
        children: [
          const Text(
            "Get in Touch",
            style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: CustomColor.whitePrimary),
          ),
          const SizedBox(height: 50),
          ConstrainedBox(
            constraints: const BoxConstraints(
              maxWidth: 700,
              maxHeight: 100,
            ),
            child: LayoutBuilder(builder: (context, Constraints) {
              if (Constraints.maxWidth >= kMinDesktopWidth) {
                return buildnameEmailFieldDesktop();
              } else {
                return buildNameEmailFieldMobile();
              }
            }),
          ),
          const SizedBox(height: 15),
          //Message
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 700),
            child: CustomTextField(
              hintText: "Your Message",
              maxLines: 16,
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          //Send button
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 700),
            child: SizedBox(
              width: double.maxFinite,
              child:
                  ElevatedButton(onPressed: () {}, child: Text("Get in Touch")),
            ),
          ),
          const SizedBox(height: 30),
          ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 300),
              child: const Divider()),
          const SizedBox(height: 15),
          //SNS icon button links
          Wrap(
            spacing: 12,
            runSpacing: 12,
            alignment: WrapAlignment.center,
            children: [
              InkWell(
                  onTap: () {
                    js.context.callMethod("open", [SnsLinks.github]);
                  },
                  child: Image.asset(
                    "assets/github.png",
                    width: 28,
                  )),
              InkWell(
                  onTap: () {
                    js.context.callMethod("open", [SnsLinks.linkedIn]);
                  },
                  child: Image.asset(
                    "assets/linkedin.png",
                    width: 28,
                  )),
              InkWell(
                  onTap: () {
                    js.context.callMethod("open", [SnsLinks.instagram]);
                  },
                  child: Image.asset(
                    "assets/instagram.png",
                    width: 28,
                  )),
              InkWell(
                  onTap: () {
                    js.context.callMethod("open", [SnsLinks.telegram]);
                  },
                  child: Image.asset(
                    "assets/telegram.png",
                    width: 28,
                  )),
              InkWell(
                  onTap: () {
                    js.context.callMethod("open", [SnsLinks.facebook]);
                  },
                  child: Image.asset(
                    "assets/facebook.png",
                    width: 28,
                  )),
            ],
          ),
        ],
      ),
    );
  }

  Row buildnameEmailFieldDesktop() {
    return Row(
      children: [
        //Name
        Flexible(
          child: CustomTextField(
            hintText: "Your Name",
          ),
        ),
        const SizedBox(width: 15),
        //Email
        Flexible(
            child: CustomTextField(
          hintText: "Your Email",
        )),
      ],
    );
  }

  Column buildNameEmailFieldMobile() {
    return Column(
      children: [
        //Name
        Flexible(
          child: CustomTextField(
            hintText: "Your Name",
          ),
        ),
        const SizedBox(height: 15),
        //Email
        Flexible(
            child: CustomTextField(
          hintText: "Your Email",
        )),
      ],
    );
  }
}
