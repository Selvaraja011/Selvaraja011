class ProjectUtils {
  final String image;
  final String title;
  final String subtitle;
  final String? androidLink;
  final String? iosLink;
  final String? webLink;

  ProjectUtils({
    required this.image,
    required this.title,
    required this.subtitle,
    this.androidLink,
    this.iosLink,
    this.webLink,
  });
}

// ###############
// HOBBY PROJECTS
List<ProjectUtils> hobbyProjectUtils = [
  ProjectUtils(
    image: 'assets/projects/Developer.png',
    title: 'Software Developer Trainee',
    subtitle:
        'Contributed to the development of a Flutter-based mobile application for Android and iOS, focusing on debugging and enhancing performance',
    /*androidLink:
        'https://play.google.com/store/apps/details?id=com.shohatech.eduza',*/
  ),
  /*ProjectUtils(
    image: 'assets/projects/02.png',
    title: 'English Dictionary App',
    subtitle:
        'This is a dictionary application for English learners to easily look up word definitions.',
    androidLink:
        'https://play.google.com/store/apps/details?id=com.shohatech.eduza_eng_dictionary',
    iosLink:
        "https://apps.apple.com/us/app/eduza-english-dictionary/id6443770339",
  ),
  ProjectUtils(
      image: 'assets/projects/03.png',
      title: 'Pocket Dictionary',
      subtitle:
          'This is a word memorising app to save and play your own words as quizes',
      androidLink:
          'https://play.google.com/store/apps/details?id=com.shohruhak.eng_pocket_dictionary',
      iosLink:
          'https://apps.apple.com/tr/app/pocket-dictionary-1/id6447465115'),
  ProjectUtils(
    image: 'assets/projects/04.png',
    title: 'Tasbeeh Counter',
    subtitle:
        'This is a simple dzikr counter app for muslims with persistent storage',
    androidLink:
        'https://play.google.com/store/apps/details?id=com.shohatech.tasbeeh',
  ),
  ProjectUtils(
    image: 'assets/projects/05.png',
    title: 'Todo App',
    subtitle: 'This is a simple task management app with persistent storage',
    androidLink:
        'https://play.google.com/store/apps/details?id=com.shohatech.todo',
    iosLink: "https://apps.apple.com/us/app/eduza-todo/id6443970333",
  ),
  ProjectUtils(
    image: 'assets/projects/06.png',
    title: 'NotePad App',
    subtitle: 'This is a note taking app for MacOS and Android',
    androidLink:
        'https://play.google.com/store/apps/details?id=com.shohatech.notepad',
    iosLink: 'https://apps.apple.com/us/app/eduza-notepad/id6443973859',
  ),*/
];

// ###############
// WORK PROJECTS
List<ProjectUtils> workProjectUtils = [
  ProjectUtils(
    image: 'assets/projects/Login Page.png',
    title: 'Login Page Application',
    subtitle:
        "Implemented features like form validation and Firebase Authentication for secure login and user management.",

    /*androidLink:
        'https://play.google.com/store/apps/details?id=kr.co.evolcano.donotstudy',
    iosLink:
        "https://apps.apple.com/kr/app/%EC%98%81%EC%96%B4%EB%A8%B8%EB%A6%AC-%EA%B3%B5%EC%9E%91%EC%86%8C/id1507102714",
*/
  ),
  ProjectUtils(
    image: 'assets/projects/Simple Calculator.png',
    title: 'Simple Calculator Application',
    subtitle:
        'operations like addition, subtraction multiplication and division with a clean and intuitive user interface',
    /*webLink: 'https://www.elo.best',*/
  ),
  ProjectUtils(
    image: 'assets/projects/To-Do List.png',
    title: 'To-Do Application',
    subtitle:
        ' Created a to-do list application that allows users to add, edit, and delete tasks.',
    /*webLink: 'https://www.externally.unavailable.project',*/
  ),
];
